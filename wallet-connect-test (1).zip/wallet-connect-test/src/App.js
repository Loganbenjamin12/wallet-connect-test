import React, { useState, useEffect } from "react";
import { ethers } from "ethers";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function App() {
  const [account, setAccount] = useState(null);
  const [balance, setBalance] = useState(null);

  const connectWallet = async () => {
    if (!window.ethereum) {
      toast.error("MetaMask is not installed.");
      return;
    }

    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const accounts = await provider.send("eth_requestAccounts", []);
      const signer = await provider.getSigner();
      const address = await signer.getAddress();
      const balanceInWei = await provider.getBalance(address);
      const balanceInEth = ethers.formatEther(balanceInWei);

      setAccount(address);
      setBalance(parseFloat(balanceInEth).toFixed(4));
      toast.success("Wallet connected!");
    } catch (err) {
      toast.error("Connection failed!");
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white p-6">
      <h1 className="text-2xl font-bold mb-4">🦊 Wallet Connect</h1>
      <button
        onClick={connectWallet}
        className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        {account ? "Connected" : "Connect Wallet"}
      </button>
      {account && (
        <div className="mt-4 text-center">
          <p><strong>Account:</strong> {account}</p>
          <p><strong>Balance:</strong> {balance} ETH</p>
        </div>
      )}
      <ToastContainer />
    </div>
  );
}

export default App;

import { useEffect, useState } from 'react'
import { ethers } from 'ethers'
import { ToastContainer, toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

function App() {
  const [walletAddress, setWalletAddress] = useState('')
  const [balance, setBalance] = useState('')

  const connectWallet = async () => {
    if (!window.ethereum) {
      toast.error('MetaMask is not installed')
      return
    }

    try {
      const provider = new ethers.BrowserProvider(window.ethereum)
      const accounts = await provider.send('eth_requestAccounts', [])
      setWalletAddress(accounts[0])

      const balance = await provider.getBalance(accounts[0])
      setBalance(ethers.formatEther(balance))
    } catch (error) {
      toast.error('Failed to connect wallet')
      console.error(error)
    }
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-white">
      <h1 className="text-3xl font-bold mb-4">Wallet Connect Test</h1>
      <button
        onClick={connectWallet}
        className="bg-blue-500 px-4 py-2 rounded hover:bg-blue-600"
      >
        Connect MetaMask
      </button>
      {walletAddress && (
        <div className="mt-4 text-center">
          <p><strong>Address:</strong> {walletAddress}</p>
          <p><strong>Balance:</strong> {balance} ETH</p>
        </div>
      )}
      <ToastContainer />
    </div>
  )
}

export default App
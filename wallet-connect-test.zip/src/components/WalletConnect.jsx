import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import { toast } from "react-toastify";

const WalletConnect = () => {
  const [walletConnected, setWalletConnected] = useState(false);
  const [account, setAccount] = useState(null);
  const [balance, setBalance] = useState(null);

  const connectWallet = async () => {
    try {
      if (!window.ethereum) {
        toast.error("MetaMask not detected.");
        return;
      }

      const provider = new ethers.BrowserProvider(window.ethereum);
      const accounts = await provider.send("eth_requestAccounts", []);
      const address = accounts[0];
      setAccount(address);
      setWalletConnected(true);

      const balanceWei = await provider.getBalance(address);
      const balanceEth = ethers.formatEther(balanceWei);
      setBalance(parseFloat(balanceEth).toFixed(4));

      toast.success("Wallet connected!");
    } catch (err) {
      if (err.code === 4001) {
        toast.warning("User rejected connection.");
      } else {
        toast.error("Connection failed.");
        console.error(err);
      }
    }
  };

  useEffect(() => {
    if (window.ethereum) {
      window.ethereum.on("accountsChanged", () => window.location.reload());
      window.ethereum.on("chainChanged", () => window.location.reload());
    }
  }, []);

  return (
    <div className="flex flex-col items-center justify-center p-6 bg-gray-100 rounded-2xl shadow-xl max-w-md mx-auto mt-10">
      <h1 className="text-2xl font-bold mb-4">Connect Wallet</h1>
      {walletConnected ? (
        <div className="text-center">
          <p className="mb-2">🧾 Address:</p>
          <p className="font-mono break-all mb-2">{account}</p>
          <p className="text-green-700">💰 Balance: {balance} ETH</p>
        </div>
      ) : (
        <button
          onClick={connectWallet}
          className="bg-blue-600 text-white px-6 py-2 rounded-xl hover:bg-blue-700 transition"
        >
          Connect MetaMask
        </button>
      )}
    </div>
  );
};

export default WalletConnect;
